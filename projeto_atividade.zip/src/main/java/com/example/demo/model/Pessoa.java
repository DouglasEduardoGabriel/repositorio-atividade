package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class Pessoa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;
    private String nome;
    @Column(unique=true)
    private String cpf;
    private Double altura;
    private Double peso;

    public Pessoa(){}
    public Pessoa(String nome,String cpf,Double altura,Double peso){
        this.nome=nome; this.cpf=cpf; this.altura=altura; this.peso=peso;
    }

    public Long getCodigo(){return codigo;}
    public void setCodigo(Long c){this.codigo=c;}
    public String getNome(){return nome;}
    public void setNome(String n){this.nome=n;}
    public String getCpf(){return cpf;}
    public void setCpf(String c){this.cpf=c;}
    public Double getAltura(){return altura;}
    public void setAltura(Double a){this.altura=a;}
    public Double getPeso(){return peso;}
    public void setPeso(Double p){this.peso=p;}
}