package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class Carro {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long codigo;
    private String marca;
    private String modelo;
    private Integer anoFabricacao;
    private Integer anoModelo;
    private Double valor;

    public Carro(){}
    public Carro(String marca,String modelo,Integer anoFabricacao,Integer anoModelo,Double valor){
        this.marca=marca; this.modelo=modelo; this.anoFabricacao=anoFabricacao;
        this.anoModelo=anoModelo; this.valor=valor;
    }

    public Long getCodigo(){return codigo;}
    public void setCodigo(Long c){this.codigo=c;}
    public String getMarca(){return marca;}
    public void setMarca(String m){this.marca=m;}
    public String getModelo(){return modelo;}
    public void setModelo(String m){this.modelo=m;}
    public Integer getAnoFabricacao(){return anoFabricacao;}
    public void setAnoFabricacao(Integer a){this.anoFabricacao=a;}
    public Integer getAnoModelo(){return anoModelo;}
    public void setAnoModelo(Integer a){this.anoModelo=a;}
    public Double getValor(){return valor;}
    public void setValor(Double v){this.valor=v;}
}