package com.example.demo;

import com.example.demo.model.Pessoa;
import com.example.demo.repository.PessoaRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class PessoaRepositoryTest {

    @Autowired
    PessoaRepository repo;

    @Test
    void testaInsercao(){
        Pessoa p = new Pessoa("Joao","123.456.789-00",1.70,70.0);
        Pessoa salvo = repo.save(p);
        assertThat(salvo.getCodigo()).isNotNull();
        assertThat(repo.findByCpf("123.456.789-00")).isPresent();
    }
}