package com.example.demo;

import com.example.demo.model.Carro;
import com.example.demo.repository.CarroRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.assertj.core.api.Assertions.assertThat;

@DataJpaTest
public class CarroRepositoryTest {

    @Autowired
    CarroRepository repo;

    @Test
    void testaInsercao(){
        Carro c = new Carro("Toyota","Corolla",2020,2021,120000.0);
        Carro salvo = repo.save(c);
        assertThat(salvo.getCodigo()).isNotNull();
        assertThat(repo.findById(salvo.getCodigo())).isPresent();
    }
}